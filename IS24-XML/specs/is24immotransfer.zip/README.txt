Sehr geehrte Damen und Herren,

diese Archiv-Datei enth�lt folgende Dokumentation zur ImmobilienScout24 XML-Schnittstelle:

	1. is24immotransfer.xsd			- das aktuelle Schema
	2. is24immotransfer.doc		- die mit XMLSpy generierte Schema-Beschreibung
	3. Beispiel_AlleTypenMin.xml		- eine exemplarische XML-Datei mit allen Immobilientypen: 
									  Die Attribute und Elemente der Objekte sind nur minimal bef�llt.
	4. Beispiel_AlleTypenMax.xml	- eine exemplarische XML-Datei mit allen Immobilientypen: 
									  Die Attribute und Elemente der Objekte sind maximal bef�llt.									  
	5. Beispiel_Beschreibung.xml		- eine exemplarische XML-Datei mit kommentierten Elementen

Copyright Immobilien Scout GmbH 1999 - 2008 $Revision: 137499 $ / $Date: 2009-10-14 10:29:13 +0200 (Wed, 14 Oct 2009) $	
